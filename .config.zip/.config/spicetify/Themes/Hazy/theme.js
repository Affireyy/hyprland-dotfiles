(() => {
    const script = document.createElement("SCRIPT");
    script.setAttribute("type", "text/javascript");
    script.setAttribute(
      "src",
      "https://astromations.github.io/Hazy/hazy.js"
    );
    document.head.appendChild(script);
  })();
